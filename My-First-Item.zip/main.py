age = 30
print(age)

age = 40
print(age)

age_new=50
print(age_new)

PI=3.14
print(PI)

maths_operation = 1+3*4/2-2
print(maths_operation)
#Float Division

float_division = 12/3
print(float_division)

#Integer Division
integer_division = 12//3
print(integer_division)